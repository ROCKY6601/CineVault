package com.cinevault.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaRecorder
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule

enum class CallState { Idle, Calling, Incoming, Connecting, Connected }

open class SdpAdapter : SdpObserver {
    override fun onCreateSuccess(p0: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(p0: String?) {}
    override fun onSetFailure(p0: String?) {}
}

open class PcObserver : PeerConnection.Observer {
    override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
    override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
    override fun onIceConnectionReceivingChange(p0: Boolean) {}
    override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
    override fun onIceCandidate(p0: IceCandidate?) {}
    override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
    override fun onAddStream(p0: MediaStream?) {}
    override fun onRemoveStream(p0: MediaStream?) {}
    override fun onDataChannel(p0: DataChannel?) {}
    override fun onRenegotiationNeeded() {}
}

object CallManager {
    var state by mutableStateOf(CallState.Idle)
    var peerName by mutableStateOf("")
    var muted by mutableStateOf(false)
    var speaker by mutableStateOf(false)
    var seconds by mutableIntStateOf(0)
    var iceText by mutableStateOf("")
    var audioWarn by mutableStateOf("")

    private var appCtx: Context? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var track: AudioTrack? = null
    private var callId: String? = null
    private var isCaller = false
    private var answerApplied = false
    private var pendingOffer: String? = null
    private var incomingReg: ListenerRegistration? = null
    private val regs = mutableListOf<ListenerRegistration>()
    private var focusRequest: AudioFocusRequest? = null
    private var timerJob: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    private fun ensureFactory(ctx: Context): PeerConnectionFactory {
        factory?.let { return it }
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(ctx.applicationContext).createInitializationOptions()
        )
        val adm = try {
            JavaAudioDeviceModule.builder(ctx.applicationContext)
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule()
        } catch (e: Exception) {
            JavaAudioDeviceModule.builder(ctx.applicationContext)
                .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                .setUseHardwareAcousticEchoCanceler(false)
                .setUseHardwareNoiseSuppressor(false)
                .createAudioDeviceModule()
        }
        val f = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory()
        factory = f
        return f
    }

    fun startIncomingListener(ctx: Context) {
        appCtx = ctx.applicationContext
        val me = Repo.uid ?: return
        incomingReg?.remove()
        incomingReg = db.collection("calls").whereEqualTo("calleeId", me).whereEqualTo("status", "ringing")
            .addSnapshotListener { snap, _ ->
                val d = snap?.documents?.firstOrNull() ?: return@addSnapshotListener
                val age = System.currentTimeMillis() - (d.getLong("createdAt") ?: 0L)
                if (state == CallState.Idle && age < 60000L) {
                    callId = d.id
                    isCaller = false
                    answerApplied = false
                    peerName = d.getString("callerName") ?: "Unknown"
                    val offer = d.get("offer") as? Map<*, *>
                    pendingOffer = offer?.get("sdp") as? String
                    state = CallState.Incoming
                    watchCallDoc(d.id)
                }
            }
    }

    fun stopIncomingListener() {
        incomingReg?.remove()
        incomingReg = null
    }

    private fun createPc(ctx: Context, onCand: (IceCandidate) -> Unit): PeerConnection {
        val f = ensureFactory(ctx)
        val ice = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("turn:openrelay.metered.ca:80")
                .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
            PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443?transport=tcp")
                .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
            PeerConnection.IceServer.builder("turn:openrelay.metered.ca:443")
                .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer(),
            PeerConnection.IceServer.builder("turns:openrelay.metered.ca:443?transport=tcp")
                .setUsername("openrelayproject").setPassword("openrelayproject").createIceServer()
        )
        val cfg = PeerConnection.RTCConfiguration(ice)
        cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val p = f.createPeerConnection(cfg, object : PcObserver() {
            override fun onIceCandidate(p0: IceCandidate?) {
                if (p0 != null) onCand(p0)
            }

            override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {
                scope.launch {
                    iceText = p0?.name ?: ""
                    when (p0) {
                        PeerConnection.IceConnectionState.CONNECTED,
                        PeerConnection.IceConnectionState.COMPLETED -> markConnected()
                        PeerConnection.IceConnectionState.FAILED -> endCall()
                        else -> {}
                    }
                }
            }
        }) ?: throw IllegalStateException("PeerConnection nahi bana")
        val srcConstraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("googHighpassFilter", "true"))
        }
        val src = f.createAudioSource(srcConstraints)
        val t = f.createAudioTrack("audio0", src)
        t.setEnabled(true)
        track = t
        val sender = p.addTrack(t, listOf("nuxus_stream"))
        try {
            val params = sender.parameters
            if (params.encodings.isNotEmpty()) {
                params.encodings[0].maxBitrateBps = 64000
                sender.parameters = params
            }
        } catch (e: Exception) { }
        return p
    }

    private fun setupAudio(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioWarn = ""
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        try {
            @Suppress("DEPRECATION")
            if (am.isMicrophoneMute) am.isMicrophoneMute = false
        } catch (e: Exception) { }
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                ).setOnAudioFocusChangeListener { }.build()
            focusRequest = req
            val res = am.requestAudioFocus(req)
            if (res != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) {
                audioWarn = "Audio focus nahi mila (result=$res). Koi aur app music/call use kar rahi ho sakti hai"
            }
        } catch (e: Exception) {
            audioWarn = "Audio focus error: " + (e.message ?: "")
        }
        am.isSpeakerphoneOn = true
        speaker = true
        try {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
            am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, max, 0)
        } catch (e: Exception) { }
        muted = false
    }

    private fun markConnected() {
        if (state == CallState.Idle || state == CallState.Connected) return
        state = CallState.Connected
        seconds = 0
        timerJob?.cancel()
        timerJob = scope.launch {
            while (true) {
                delay(1000)
                seconds++
            }
        }
    }

    private fun candMap(c: IceCandidate): Map<String, Any?> =
        mapOf("sdpMid" to c.sdpMid, "sdpMLineIndex" to c.sdpMLineIndex, "candidate" to c.sdp)

    private fun listenCandidates(id: String, sub: String) {
        regs += db.collection("calls").document(id).collection(sub).addSnapshotListener { snap, _ ->
            snap?.documentChanges?.forEach { ch ->
                if (ch.type == DocumentChange.Type.ADDED) {
                    val d = ch.document
                    pc?.addIceCandidate(
                        IceCandidate(
                            d.getString("sdpMid"), (d.getLong("sdpMLineIndex") ?: 0L).toInt(),
                            d.getString("candidate") ?: ""
                        )
                    )
                }
            }
        }
    }

    private fun watchCallDoc(id: String) {
        regs += db.collection("calls").document(id).addSnapshotListener { snap, _ ->
            if (snap == null || !snap.exists()) return@addSnapshotListener
            val status = snap.getString("status")
            if (status == "ended" || status == "rejected") {
                cleanup()
                return@addSnapshotListener
            }
            if (isCaller && !answerApplied) {
                val ans = snap.get("answer") as? Map<*, *>
                val sdp = ans?.get("sdp") as? String
                if (sdp != null) {
                    answerApplied = true
                    state = CallState.Connecting
                    pc?.setRemoteDescription(object : SdpAdapter() {
                        override fun onSetSuccess() {
                            scope.launch { listenCandidates(id, "calleeCandidates") }
                        }
                    }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
                }
            }
        }
    }

    fun startCall(peerUid: String, name: String) {
        if (state != CallState.Idle) return
        val ctx = appCtx ?: return
        val me = Repo.uid ?: return
        peerName = name
        isCaller = true
        answerApplied = false
        state = CallState.Calling
        val id = db.collection("calls").document().id
        callId = id
        try {
            setupAudio(ctx)
            val p = createPc(ctx) { c ->
                db.collection("calls").document(id).collection("callerCandidates").add(candMap(c))
            }
            pc = p
            p.createOffer(object : SdpAdapter() {
                override fun onCreateSuccess(p0: SessionDescription?) {
                    if (p0 == null) return
                    p.setLocalDescription(object : SdpAdapter() {
                        override fun onSetSuccess() {
                            db.collection("calls").document(id).set(
                                mapOf(
                                    "callerId" to me, "callerName" to Repo.myName,
                                    "calleeId" to peerUid, "calleeName" to name,
                                    "status" to "ringing", "createdAt" to System.currentTimeMillis(),
                                    "offer" to mapOf("type" to "offer", "sdp" to p0.description)
                                )
                            )
                            scope.launch { watchCallDoc(id) }
                        }
                    }, p0)
                }
            }, MediaConstraints())
            scope.launch {
                delay(45000)
                if (state == CallState.Calling) endCall()
            }
        } catch (e: Exception) {
            cleanup()
        }
    }

    fun accept() {
        val ctx = appCtx ?: return
        val id = callId ?: return
        val offerSdp = pendingOffer ?: return
        if (state != CallState.Incoming) return
        state = CallState.Connecting
        try {
            setupAudio(ctx)
            val p = createPc(ctx) { c ->
                db.collection("calls").document(id).collection("calleeCandidates").add(candMap(c))
            }
            pc = p
            p.setRemoteDescription(object : SdpAdapter() {
                override fun onSetSuccess() {
                    p.createAnswer(object : SdpAdapter() {
                        override fun onCreateSuccess(p0: SessionDescription?) {
                            if (p0 == null) return
                            p.setLocalDescription(object : SdpAdapter() {
                                override fun onSetSuccess() {
                                    db.collection("calls").document(id).update(
                                        mapOf(
                                            "answer" to mapOf("type" to "answer", "sdp" to p0.description),
                                            "status" to "accepted"
                                        )
                                    )
                                    scope.launch { listenCandidates(id, "callerCandidates") }
                                }
                            }, p0)
                        }
                    }, MediaConstraints())
                }
            }, SessionDescription(SessionDescription.Type.OFFER, offerSdp))
        } catch (e: Exception) {
            cleanup()
        }
    }

    fun reject() {
        callId?.let { db.collection("calls").document(it).update("status", "rejected") }
        cleanup()
    }

    fun endCall() {
        callId?.let { db.collection("calls").document(it).update("status", "ended") }
        cleanup()
    }

    fun toggleMute() {
        muted = !muted
        track?.setEnabled(!muted)
    }

    fun toggleSpeaker() {
        speaker = !speaker
        val ctx = appCtx ?: return
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isSpeakerphoneOn = speaker
    }

    private fun cleanup() {
        if (state == CallState.Idle && callId == null) return
        timerJob?.cancel()
        timerJob = null
        regs.forEach { it.remove() }
        regs.clear()
        try { pc?.close() } catch (e: Exception) { }
        try { pc?.dispose() } catch (e: Exception) { }
        pc = null
        track = null
        appCtx?.let {
            val am = it.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
            am.isSpeakerphoneOn = false
            try { focusRequest?.let { fr -> am.abandonAudioFocusRequest(fr) } } catch (e: Exception) { }
            focusRequest = null
        }
        callId = null
        pendingOffer = null
        answerApplied = false
        muted = false
        speaker = false
        seconds = 0
        peerName = ""
        iceText = ""
        audioWarn = ""
        state = CallState.Idle
    }
}

@Composable
fun rememberMicGate(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pending?.invoke()
        pending = null
    }
    return { action ->
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (granted) action() else {
            pending = action
            launcher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
}

@Composable
fun PulseRings(active: Boolean) {
    val inf = rememberInfiniteTransition(label = "rings")
    val p by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "p")
    Canvas(Modifier.size(280.dp)) {
        if (active) {
            for (k in 0..2) {
                val f = (p + k / 3f) % 1f
                drawCircle(
                    Violet.copy(alpha = (1f - f) * 0.55f),
                    radius = size.minDimension / 2f * (0.45f + 0.55f * f),
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }
    }
}

@Composable
fun RoundAction(icon: ImageVector, label: String, color: Color, size: androidx.compose.ui.unit.Dp = 70.dp, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Tilt3D(Modifier.size(size), CircleShape, onClick) {
            Box(Modifier.fillMaxSize().background(color), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(size / 2.2f))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

@Composable
fun CallScreen() {
    val gate = rememberMicGate()
    val ctx = LocalContext.current
    val st = CallManager.state
    val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    BackHandler(true) { }
    AuroraBackground(Modifier.fillMaxSize().pointerInput(Unit) { }) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(72.dp))
            val status = when (st) {
                CallState.Incoming -> "Incoming voice call"
                CallState.Calling -> "Calling..."
                CallState.Connecting -> "Connecting..."
                CallState.Connected -> "%02d:%02d".format(CallManager.seconds / 60, CallManager.seconds % 60)
                else -> ""
            }
            Text(CallManager.peerName, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(6.dp))
            Text(status, color = Cyan, fontSize = 16.sp)
            if (!micGranted) {
                Text("Mic permission band hai. Phone Settings > Apps > NUXUS MOVIES > Permissions me Microphone ON karo", color = Pink, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (CallManager.iceText.isNotEmpty()) Text("connection: " + CallManager.iceText.lowercase(), color = Color.White.copy(alpha = 0.35f), fontSize = 11.sp)
            if (CallManager.audioWarn.isNotEmpty()) Text(CallManager.audioWarn, color = Gold, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.weight(1f))
            Box(contentAlignment = Alignment.Center) {
                PulseRings(active = st != CallState.Connected)
                Tilt3D(Modifier.size(140.dp), CircleShape) { Avatar(CallManager.peerName, 140.dp) }
            }
            Spacer(Modifier.weight(1f))
            when (st) {
                CallState.Incoming -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundAction(Icons.Filled.CallEnd, "Decline", Color(0xFFE53935), 76.dp) { CallManager.reject() }
                    RoundAction(Icons.Filled.Call, "Accept", Color(0xFF00C853), 76.dp) { gate { CallManager.accept() } }
                }
                CallState.Connected -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    RoundAction(
                        if (CallManager.muted) Icons.Filled.MicOff else Icons.Filled.Mic, "Mute",
                        if (CallManager.muted) Violet else Color.White.copy(alpha = 0.18f)
                    ) { CallManager.toggleMute() }
                    RoundAction(Icons.Filled.CallEnd, "End", Color(0xFFE53935), 78.dp) { CallManager.endCall() }
                    RoundAction(
                        Icons.Filled.VolumeUp, "Speaker",
                        if (CallManager.speaker) Violet else Color.White.copy(alpha = 0.18f)
                    ) { CallManager.toggleSpeaker() }
                }
                else -> RoundAction(Icons.Filled.CallEnd, "End", Color(0xFFE53935), 78.dp) { CallManager.endCall() }
            }
            Spacer(Modifier.height(48.dp))
        }
    }
}
