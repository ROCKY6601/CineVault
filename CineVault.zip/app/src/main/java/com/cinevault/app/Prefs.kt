package com.cinevault.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class Movie(
    val id: String,
    val title: String,
    val category: String,
    val year: String,
    val desc: String,
    val thumb: String,
    val directUrl: String? = null
)

data class HistoryItem(val movie: Movie, val posMs: Long, val durMs: Long)

fun movieToJson(m: Movie): JSONObject = JSONObject()
    .put("id", m.id).put("title", m.title).put("cat", m.category).put("year", m.year)
    .put("desc", m.desc).put("thumb", m.thumb).put("direct", m.directUrl ?: "")

fun jsonToMovie(o: JSONObject): Movie = Movie(
    o.optString("id"), o.optString("title"), o.optString("cat"), o.optString("year"),
    o.optString("desc"), o.optString("thumb"), o.optString("direct").ifEmpty { null }
)

object Prefs {
    private var sp: SharedPreferences? = null

    var accentIndex by mutableIntStateOf(0)
    var heroAuto by mutableStateOf(true)
    var wifiOnly by mutableStateOf(false)
    val favorites = mutableStateListOf<Movie>()
    val history = mutableStateListOf<HistoryItem>()

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("nuxus_prefs", Context.MODE_PRIVATE)
        sp = p
        accentIndex = p.getInt("accent", 0)
        heroAuto = p.getBoolean("heroAuto", true)
        wifiOnly = p.getBoolean("wifiOnly", false)
        favorites.clear()
        history.clear()
        try {
            val fa = JSONArray(p.getString("fav", "[]"))
            for (i in 0 until fa.length()) favorites.add(jsonToMovie(fa.getJSONObject(i)))
            val ha = JSONArray(p.getString("hist", "[]"))
            for (i in 0 until ha.length()) {
                val o = ha.getJSONObject(i)
                history.add(HistoryItem(jsonToMovie(o), o.optLong("pos"), o.optLong("dur")))
            }
        } catch (e: Exception) { }
        history.removeAll { !it.movie.id.startsWith("up_") }
        favorites.removeAll { !it.id.startsWith("up_") }
    }

    fun setAccent(i: Int) {
        accentIndex = i
        sp?.edit()?.putInt("accent", i)?.apply()
    }

    fun updateHeroAuto(v: Boolean) {
        heroAuto = v
        sp?.edit()?.putBoolean("heroAuto", v)?.apply()
    }

    fun updateWifiOnly(v: Boolean) {
        wifiOnly = v
        sp?.edit()?.putBoolean("wifiOnly", v)?.apply()
    }

    fun isFav(id: String): Boolean = favorites.any { it.id == id }

    fun toggleFav(m: Movie) {
        val i = favorites.indexOfFirst { it.id == m.id }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, m)
        val arr = JSONArray()
        favorites.forEach { arr.put(movieToJson(it)) }
        sp?.edit()?.putString("fav", arr.toString())?.apply()
    }

    private fun saveHistory() {
        val arr = JSONArray()
        history.forEach { arr.put(movieToJson(it.movie).put("pos", it.posMs).put("dur", it.durMs)) }
        sp?.edit()?.putString("hist", arr.toString())?.apply()
    }

    fun saveProgress(m: Movie, pos: Long, dur: Long) {
        if (pos < 3000L) return
        val idx = history.indexOfFirst { it.movie.id == m.id }
        if (idx >= 0) history.removeAt(idx)
        val finished = dur > 0 && pos >= dur - 20000L
        if (!finished) {
            history.add(0, HistoryItem(m, pos, dur))
            while (history.size > 20) history.removeAt(history.lastIndex)
        }
        saveHistory()
    }

    fun progressOf(id: String): Long = history.firstOrNull { it.movie.id == id }?.posMs ?: 0L

    fun clearHistory() {
        history.clear()
        saveHistory()
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    fun unlockOk(code: String): Boolean {
        val saved = sp?.getString("unlockHash", null) ?: sha("1234")
        return sha(code) == saved
    }

    fun setUnlock(code: String) {
        sp?.edit()?.putString("unlockHash", sha(code))?.apply()
    }
}
