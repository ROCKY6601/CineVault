package com.cinevault.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(onDone: () -> Unit, onBack: () -> Unit) {
    var signup by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    BackHandler { onBack() }

    val inf = rememberInfiniteTransition(label = "logo")
    val swing by inf.animateFloat(
        -28f, 28f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "swing"
    )

    AuroraBackground(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(40.dp))
            Box(
                Modifier.size(96.dp)
                    .graphicsLayer { rotationY = swing; rotationX = -swing / 3f; cameraDistance = 14f * density }
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Violet, Pink))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(46.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text(
                if (signup) "Create your account" else "Welcome back",
                color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center
            )
            Text(
                if (signup) "Private chat & calls, sirf aapke liye" else "Login karke chat shuru karo",
                color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp
            )
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), 0.07f).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AnimatedVisibility(signup) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        GlassField(name, { name = it }, "Name", Icons.Filled.Person)
                        GlassField(username, { username = it }, "Username", Icons.Filled.AlternateEmail)
                    }
                }
                GlassField(email, { email = it }, "Email", Icons.Filled.Email, keyboard = KeyboardType.Email)
                GlassField(password, { password = it }, "Password", Icons.Filled.Lock, password = true)
                val err = error
                if (err != null) Text(err, color = Pink, fontSize = 13.sp)
                val inf = info
                if (inf != null) Text(inf, color = Color(0xFF00E676), fontSize = 13.sp)
                GradientButton(if (signup) "Create account" else "Login", loading = loading) {
                    scope.launch {
                        loading = true
                        error = null
                        try {
                            if (signup) Repo.signUp(name, username, email, password) else Repo.login(email, password)
                            Repo.setOnline(true)
                            onDone()
                        } catch (e: Exception) {
                            val msg = e.message ?: ""
                            error = when {
                                msg.contains("credential", true) || msg.contains("password is invalid", true) ->
                                    "Email ya password galat hai, ya is email se account bana hi nahi. Naya account banao ya Password bhool gaye dabao"
                                msg.contains("network", true) -> "Internet check karo"
                                msg.contains("already in use", true) -> "Is email se account pehle se hai. Login karo"
                                msg.isEmpty() -> "Kuch gadbad hui"
                                else -> msg
                            }
                        }
                        loading = false
                    }
                }
                if (!signup) {
                    Text(
                        "Password bhool gaye?", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.CenterHorizontally).clickable {
                            scope.launch {
                                error = null
                                info = null
                                try {
                                    Repo.resetPassword(email)
                                    info = "Password reset email bhej diya. Inbox ya spam check karo"
                                } catch (e: Exception) {
                                    error = e.message ?: "Email nahi bhej paye"
                                }
                            }
                        }.padding(4.dp)
                    )
                }
                Text(
                    if (signup) "Pehle se account hai? Login" else "Naya account banao",
                    color = Cyan, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                        .clickable { signup = !signup; error = null; info = null }.padding(8.dp)
                )
            }
        }
    }
}
