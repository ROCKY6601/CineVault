package com.cinevault.app

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Environment
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun enqueueDownload(ctx: Context, m: Movie, url: String) {
    val safe = m.title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifEmpty { m.id }
    val net = if (Prefs.wifiOnly) DownloadManager.Request.NETWORK_WIFI
    else DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE
    val req = DownloadManager.Request(Uri.parse(url))
        .setTitle(m.title)
        .setDescription("NUXUS MOVIES")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedNetworkTypes(net)
        .setDestinationInExternalFilesDir(ctx, Environment.DIRECTORY_MOVIES, "$safe.mp4")
    (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
}

@Composable
fun PlayerScreen(req: PlayReq, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx.findActivity()
    val exo = remember(req) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(req.url))
            if (req.startMs > 0L) seekTo(req.startMs)
            prepare()
            playWhenReady = true
        }
    }
    val isLocal = req.movie.id.startsWith("local_")

    DisposableEffect(req) {
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val w = activity?.window
        val ctrl = if (w != null) WindowInsetsControllerCompat(w, w.decorView) else null
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            if (!isLocal) {
                val d = exo.duration
                Prefs.saveProgress(req.movie, exo.currentPosition, if (d > 0L) d else 0L)
            }
            exo.release()
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(req) {
        while (true) {
            delay(10000)
            if (!isLocal) {
                val d = exo.duration
                Prefs.saveProgress(req.movie, exo.currentPosition, if (d > 0L) d else 0L)
            }
        }
    }

    BackHandler { onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = true
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        IconButton(onClick = onClose, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }
    }
}

@Composable
fun LibraryScreen(onOpen: (Movie) -> Unit, onPlayLocal: (File) -> Unit) {
    var sub by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Library")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("My List", "Downloads", "History").forEachIndexed { i, s ->
                val on = sub == i
                val bg by animateColorAsState(if (on) Violet else Color.White.copy(alpha = 0.08f), label = "lib")
                Text(
                    s, color = Color.White, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(bg)
                        .clickable { sub = i }.padding(horizontal = 18.dp, vertical = 9.dp)
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.weight(1f)) {
            when (sub) {
                0 -> MyListTab(onOpen)
                1 -> DownloadsTab(onPlayLocal)
                else -> HistoryTab(onOpen)
            }
        }
    }
}

@Composable
fun MyListTab(onOpen: (Movie) -> Unit) {
    val favs = Prefs.favorites.toList()
    if (favs.isEmpty()) {
        EmptyCard("Abhi kuch nahi. Movie ke page par My List dabao")
    } else {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            items(favs, key = { it.id }) { m ->
                MovieListRow(m, onOpen, trailing = {
                    IconButton(onClick = { Prefs.toggleFav(m) }) { Icon(Icons.Filled.Favorite, null, tint = Pink) }
                })
            }
        }
    }
}

@Composable
fun HistoryTab(onOpen: (Movie) -> Unit) {
    val list = Prefs.history.toList()
    if (list.isEmpty()) {
        EmptyCard("Abhi tak kuch nahi dekha")
    } else {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            items(list, key = { it.movie.id }) { h ->
                MovieListRow(h.movie, onOpen, extra = "Yahan tak dekha: ${fmtMs(h.posMs)}")
            }
        }
    }
}

@Composable
fun DownloadsTab(onPlay: (File) -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            tick++
        }
    }
    val files = remember(tick) {
        ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES)?.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".mp4") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    if (files.isEmpty()) {
        EmptyCard("Koi download nahi. Movie ke page par Download dabao")
    } else {
        LazyColumn(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)
        ) {
            items(files, key = { it.name }) { f ->
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.07f).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Movie, null, tint = Cyan, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.nameWithoutExtension, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text("%.1f MB".format(f.length() / 1048576.0), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                    }
                    IconButton(onClick = { onPlay(f) }) { Icon(Icons.Filled.PlayArrow, null, tint = Cyan) }
                    IconButton(onClick = { f.delete(); tick++ }) { Icon(Icons.Filled.Delete, null, tint = Pink) }
                }
            }
        }
    }
}
