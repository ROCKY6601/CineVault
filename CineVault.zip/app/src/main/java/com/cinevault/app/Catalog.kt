package com.cinevault.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

object Catalog {
    var uploads by mutableStateOf(listOf<Movie>())

    val categories: List<String>
        get() = listOf("All") + uploads.map { it.category }.distinct()

    fun all(): List<Movie> = uploads

    fun listenUploads(): ListenerRegistration? = try {
        FirebaseFirestore.getInstance().collection("movies")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    uploads = snap.documents.map { d ->
                        Movie(
                            "up_" + d.id, d.getString("title") ?: "", d.getString("category") ?: "Movies",
                            d.getString("year") ?: "", d.getString("desc") ?: "",
                            d.getString("thumb") ?: "", d.getString("video")
                        )
                    }.filter { it.title.isNotBlank() && (it.directUrl ?: "").startsWith("http") }
                }
            }
    } catch (e: Exception) {
        null
    }

    suspend fun resolveUrl(m: Movie): String? = m.directUrl
}
