package com.cinevault.app

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Catalog {
    private const val GB = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample"
    private const val NSFW = " AND NOT subject:(nudity OR erotica OR sexploitation OR adult)"

    val categories = listOf("All", "Movies", "Animation", "Classic TV", "Sci-Fi", "Horror", "Comedy", "Drama")

    // Blender Foundation open movies (Creative Commons BY) - direct, always-working links
    val openMovies = listOf(
        Movie(
            "bbb", "Big Buck Bunny", "Animation", "2008",
            "A giant, gentle rabbit takes clever revenge on three bullying rodents. Blender Foundation open movie (CC BY 3.0).",
            "$GB/images/BigBuckBunny.jpg", "$GB/BigBuckBunny.mp4"
        ),
        Movie(
            "sintel", "Sintel", "Animation", "2010",
            "A lonely young woman searches the world for the baby dragon she once befriended. Blender Foundation open movie (CC BY 3.0).",
            "$GB/images/Sintel.jpg", "$GB/Sintel.mp4"
        ),
        Movie(
            "tos", "Tears of Steel", "Sci-Fi", "2012",
            "In a future Amsterdam, a group of warriors and scientists try to save the world from killer robots. Blender Foundation open movie (CC BY 3.0).",
            "$GB/images/TearsOfSteel.jpg", "$GB/TearsOfSteel.mp4"
        ),
        Movie(
            "ed", "Elephants Dream", "Animation", "2006",
            "Two strangers explore a strange, surreal machine world. The first open movie by the Blender Foundation (CC BY 2.5).",
            "$GB/images/ElephantsDream.jpg", "$GB/ElephantsDream.mp4"
        )
    )

    private val queries = linkedMapOf(
        "Movies" to "collection:feature_films AND mediatype:movies$NSFW",
        "Animation" to "collection:animationandcartoons AND mediatype:movies$NSFW",
        "Classic TV" to "collection:classic_tv AND mediatype:movies$NSFW",
        "Sci-Fi" to "collection:feature_films AND subject:\"science fiction\" AND mediatype:movies$NSFW",
        "Horror" to "collection:feature_films AND subject:horror AND mediatype:movies$NSFW",
        "Comedy" to "collection:feature_films AND subject:comedy AND mediatype:movies$NSFW",
        "Drama" to "collection:feature_films AND subject:drama AND mediatype:movies$NSFW"
    )

    val sections = mutableStateMapOf<String, List<Movie>>()
    var loading by mutableStateOf(false)
    private val urlCache = mutableMapOf<String, String>()

    fun all(): List<Movie> =
        (openMovies + sections.values.flatten()).distinctBy { it.id }

    suspend fun load(force: Boolean = false) {
        if (loading) return
        if (!force && sections.isNotEmpty()) return
        loading = true
        try {
            val results = coroutineScope {
                queries.map { (cat, q) -> async(Dispatchers.IO) { cat to fetch(q, cat, 24) } }.awaitAll()
            }
            results.forEach { (cat, list) -> if (list.isNotEmpty()) sections[cat] = list }
        } finally {
            loading = false
        }
    }

    suspend fun search(text: String): List<Movie> = withContext(Dispatchers.IO) {
        val words = text.split(" ").map { w -> w.filter { it.isLetterOrDigit() } }.filter { it.isNotEmpty() }
        if (words.isEmpty()) return@withContext emptyList<Movie>()
        val t = words.joinToString(" AND ") { "$it*" }
        fetch(
            "title:($t) AND mediatype:movies AND collection:(feature_films OR classic_tv OR animationandcartoons)$NSFW",
            "Movies", 30
        )
    }

    private fun http(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("User-Agent", "NuxusMovies/3.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun fetch(q: String, cat: String, rows: Int): List<Movie> {
        return try {
            val url = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8") +
                "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&fl%5B%5D=description" +
                "&sort%5B%5D=downloads+desc&rows=$rows&page=1&output=json"
            parse(http(url), cat)
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun flat(v: Any?): String {
        if (v == null || v == JSONObject.NULL) return ""
        if (v is JSONArray) return if (v.length() > 0) v.optString(0) else ""
        return v.toString()
    }

    private fun parse(json: String, cat: String): List<Movie> {
        val docs = JSONObject(json).getJSONObject("response").getJSONArray("docs")
        val out = mutableListOf<Movie>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isEmpty()) continue
            val title = flat(d.opt("title")).ifBlank { id }
            val desc = flat(d.opt("description")).replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim().take(450)
            out.add(
                Movie(
                    id, title, cat, flat(d.opt("year")),
                    desc.ifBlank { "Public domain film from the Internet Archive." },
                    "https://archive.org/services/img/$id"
                )
            )
        }
        return out
    }

    suspend fun resolveUrl(m: Movie): String? = withContext(Dispatchers.IO) {
        m.directUrl?.let { return@withContext it }
        urlCache[m.id]?.let { return@withContext it }
        try {
            val files = JSONObject(http("https://archive.org/metadata/${m.id}")).getJSONArray("files")
            var best: String? = null
            for (i in 0 until files.length()) {
                val f = files.getJSONObject(i)
                val name = f.optString("name")
                val fmt = f.optString("format")
                if (name.endsWith(".mp4", true)) {
                    if (fmt.contains("264") || fmt.contains("MPEG4")) {
                        best = name
                        break
                    }
                    if (best == null) best = name
                }
            }
            val b = best ?: return@withContext null
            val url = "https://archive.org/download/${m.id}/" + Uri.encode(b, "/")
            urlCache[m.id] = url
            url
        } catch (e: Exception) {
            null
        }
    }
}
