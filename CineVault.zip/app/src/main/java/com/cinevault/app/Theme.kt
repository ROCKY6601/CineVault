package com.cinevault.app

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF07070D)
val Surf = Color(0xFF12121C)
val Violet = Color(0xFF7C4DFF)
val Cyan = Color(0xFF00E5FF)
val Pink = Color(0xFFFF4081)
val Gold = Color(0xFFFFC857)

@Composable
fun CineTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet, background = Bg, surface = Surf,
            onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

fun Modifier.glass(shape: Shape = RoundedCornerShape(20.dp), alpha: Float = 0.08f): Modifier =
    this.clip(shape)
        .background(Color.White.copy(alpha = alpha))
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = 0.35f), Color.White.copy(alpha = 0.04f))),
            shape
        )

@Composable
fun AuroraBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    Box(modifier.background(Bg)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * (0.1f + 0.7f * a), h * 0.12f)
            val c2 = Offset(w * (0.9f - 0.7f * a), h * 0.55f)
            val c3 = Offset(w * (0.2f + 0.5f * a), h * 0.95f)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = 0.40f), Color.Transparent), c1, w), w, c1)
            drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.22f), Color.Transparent), c2, w * 0.8f), w * 0.8f, c2)
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.20f), Color.Transparent), c3, w * 0.9f), w * 0.9f, c3)
        }
        content()
    }
}

@Composable
fun Tilt3D(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    onClick: () -> Unit = {},
    content: @Composable BoxScope.() -> Unit
) {
    var rx by remember { mutableFloatStateOf(0f) }
    var ry by remember { mutableFloatStateOf(0f) }
    var pressed by remember { mutableStateOf(false) }
    var boxSize by remember { mutableStateOf(IntSize(1, 1)) }
    val arx by animateFloatAsState(rx, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "rx")
    val ary by animateFloatAsState(ry, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "ry")
    val sc by animateFloatAsState(if (pressed) 0.96f else 1f, spring(), label = "sc")
    Box(
        modifier
            .onSizeChanged { boxSize = it }
            .graphicsLayer {
                rotationX = arx
                rotationY = ary
                scaleX = sc
                scaleY = sc
                cameraDistance = 14f * density
            }
            .shadow(10.dp, shape, spotColor = Violet.copy(alpha = 0.7f))
            .clip(shape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { o ->
                        pressed = true
                        ry = ((o.x / boxSize.width) - 0.5f) * 26f
                        rx = -((o.y / boxSize.height) - 0.5f) * 26f
                        tryAwaitRelease()
                        pressed = false
                        rx = 0f
                        ry = 0f
                    },
                    onTap = { onClick() }
                )
            },
        content = content
    )
}

@Composable
fun Avatar(name: String, size: Dp, online: Boolean = false) {
    val pal = listOf(Violet to Cyan, Pink to Gold, Color(0xFF00C853) to Cyan, Color(0xFFFF6D00) to Pink)
    val p = pal[(name.hashCode() and 0x7fffffff) % pal.size]
    Box(Modifier.size(size)) {
        Box(
            Modifier.fillMaxSize().clip(CircleShape).background(Brush.linearGradient(listOf(p.first, p.second))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                name.take(1).uppercase(), color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = (size.value / 2.3f).sp
            )
        }
        if (online) {
            Box(
                Modifier.size(size / 4).align(Alignment.BottomEnd).clip(CircleShape)
                    .background(Color(0xFF00E676)).border(2.dp, Bg, CircleShape)
            )
        }
    }
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, loading: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(27.dp))
            .background(Brush.horizontalGradient(listOf(Violet, Pink)))
            .clickable(enabled = !loading, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun GlassField(
    value: String, onChange: (String) -> Unit, label: String, icon: ImageVector,
    modifier: Modifier = Modifier, password: Boolean = false, keyboard: KeyboardType = KeyboardType.Text
) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label) }, singleLine = true,
        leadingIcon = { Icon(icon, null) },
        trailingIcon = {
            if (password) {
                IconButton(onClick = { show = !show }) {
                    Icon(if (show) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null)
                }
            }
        },
        visualTransformation = if (password && !show) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = Violet, unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
            focusedLabelColor = Cyan, unfocusedLabelColor = Color.White.copy(alpha = 0.6f),
            cursorColor = Cyan,
            focusedContainerColor = Color.White.copy(alpha = 0.05f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.05f)
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun FloatingNav(
    items: List<Pair<ImageVector, String>>, tab: Int, onTab: (Int) -> Unit, modifier: Modifier = Modifier
) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)
            .glass(RoundedCornerShape(32.dp), 0.12f).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, pair ->
            val sel = tab == i
            val bg by animateColorAsState(if (sel) Violet else Color.Transparent, label = "nb")
            Row(
                Modifier.clip(RoundedCornerShape(26.dp)).background(bg)
                    .clickable { onTab(i) }.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(pair.first, null, tint = Color.White)
                AnimatedVisibility(sel) {
                    Text(pair.second, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }
}
