package com.cinevault.app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

data class UserProfile(val uid: String, val name: String, val username: String, val email: String, val online: Boolean)
data class ChatMsg(val id: String, val text: String, val senderId: String, val time: Long)
data class ChatSummary(val chatId: String, val otherUid: String, val last: String, val time: Long)

object Repo {
    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    val uid: String? get() = try { auth.currentUser?.uid } catch (e: Exception) { null }
    val myName: String get() = auth.currentUser?.displayName ?: "User"

    fun chatId(a: String, b: String): String = listOf(a, b).sorted().joinToString("_")

    suspend fun signUp(name: String, username: String, email: String, password: String) {
        val uname = username.trim().lowercase()
        require(name.isNotBlank()) { "Name likho" }
        require(Regex("^[a-z0-9_]{3,20}$").matches(uname)) { "Username 3-20 characters: a-z, 0-9, _" }
        require(email.contains("@")) { "Sahi email likho" }
        require(password.length >= 6) { "Password kam se kam 6 characters ka ho" }
        if (db.collection("usernames").document(uname).get().await().exists()) {
            throw IllegalStateException("Yeh username pehle se liya hua hai")
        }
        val res = auth.createUserWithEmailAndPassword(email.trim(), password).await()
        val user = res.user ?: throw IllegalStateException("Account nahi bana")
        try {
            user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
            val batch = db.batch()
            batch.set(db.collection("usernames").document(uname), mapOf("uid" to user.uid))
            batch.set(
                db.collection("users").document(user.uid),
                mapOf(
                    "name" to name.trim(), "username" to uname, "email" to email.trim(),
                    "online" to true, "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
        } catch (e: Exception) {
            try { user.delete().await() } catch (e2: Exception) { }
            throw IllegalStateException("Username already taken ya Firestore rules check karo")
        }
    }

    suspend fun login(email: String, password: String) {
        require(email.contains("@")) { "Sahi email likho" }
        require(password.isNotEmpty()) { "Password likho" }
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun updateName(newName: String) {
        val u = auth.currentUser ?: return
        val n = newName.trim()
        require(n.isNotEmpty()) { "Name khali nahi ho sakta" }
        u.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(n).build()).await()
        db.collection("users").document(u.uid).update("name", n).await()
    }

    suspend fun addMovie(title: String, category: String, year: String, desc: String, thumb: String, video: String) {
        val me = uid ?: throw IllegalStateException("Pehle login karo")
        require(title.isNotBlank()) { "Title likho" }
        require(video.trim().startsWith("http")) { "Video URL https:// se shuru hona chahiye" }
        try {
            db.collection("movies").add(
                mapOf(
                    "title" to title.trim(), "category" to category.trim().ifEmpty { "Movies" },
                    "year" to year.trim(), "desc" to desc.trim(), "thumb" to thumb.trim(),
                    "video" to video.trim(), "owner" to me, "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } catch (e: Exception) {
            if ((e.message ?: "").contains("PERMISSION", true)) {
                throw IllegalStateException("Sirf admin email movie add kar sakta hai. Firestore rules me apna email daalo")
            }
            throw e
        }
    }

    fun logout() {
        setOnline(false)
        auth.signOut()
    }

    fun setOnline(flag: Boolean) {
        val u = uid ?: return
        try {
            db.collection("users").document(u).update("online", flag)
        } catch (e: Exception) { }
    }

    private fun ts(d: DocumentSnapshot, field: String): Long =
        d.getTimestamp(field, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0L

    fun listenUsers(onData: (List<UserProfile>) -> Unit): ListenerRegistration =
        db.collection("users").limit(300).addSnapshotListener { snap, _ ->
            if (snap != null) {
                onData(snap.documents.map { d ->
                    UserProfile(
                        d.id, d.getString("name") ?: "", d.getString("username") ?: "",
                        d.getString("email") ?: "", d.getBoolean("online") == true
                    )
                })
            }
        }

    fun listenChats(onData: (List<ChatSummary>) -> Unit): ListenerRegistration {
        val me = uid ?: ""
        return db.collection("chats").whereArrayContains("participants", me).addSnapshotListener { snap, _ ->
            if (snap != null) {
                onData(snap.documents.map { d ->
                    val parts = d.get("participants") as? List<*> ?: emptyList<Any>()
                    ChatSummary(
                        d.id, parts.firstOrNull { it != me } as? String ?: "",
                        d.getString("last") ?: "", ts(d, "lastTime")
                    )
                }.sortedByDescending { it.time })
            }
        }
    }

    fun listenMessages(otherUid: String, onData: (List<ChatMsg>) -> Unit): ListenerRegistration {
        val cid = chatId(uid ?: "", otherUid)
        return db.collection("chats").document(cid).collection("messages").orderBy("time")
            .addSnapshotListener { snap, _ ->
                if (snap != null) {
                    onData(snap.documents.map { d ->
                        ChatMsg(d.id, d.getString("text") ?: "", d.getString("senderId") ?: "", ts(d, "time"))
                    })
                }
            }
    }

    suspend fun sendMessage(otherUid: String, text: String) {
        val me = uid ?: return
        val cid = chatId(me, otherUid)
        db.collection("chats").document(cid).set(
            mapOf(
                "participants" to listOf(me, otherUid), "last" to text,
                "lastTime" to FieldValue.serverTimestamp(), "lastSender" to me
            ),
            SetOptions.merge()
        ).await()
        db.collection("chats").document(cid).collection("messages").add(
            mapOf("text" to text, "senderId" to me, "time" to FieldValue.serverTimestamp())
        ).await()
    }
}
