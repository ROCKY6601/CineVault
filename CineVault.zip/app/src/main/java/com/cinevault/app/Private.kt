@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.cinevault.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmtTime(ms: Long): String =
    if (ms == 0L) "" else SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(ms))

@Composable
fun PrivateApp(onExit: () -> Unit) {
    val ctx = LocalContext.current
    var users by remember { mutableStateOf(listOf<UserProfile>()) }
    var chats by remember { mutableStateOf(listOf<ChatSummary>()) }
    var tab by remember { mutableIntStateOf(0) }
    var chatWith by remember { mutableStateOf<UserProfile?>(null) }

    DisposableEffect(Unit) {
        val r1 = Repo.listenUsers { users = it }
        val r2 = Repo.listenChats { chats = it }
        CallManager.startIncomingListener(ctx)
        onDispose {
            r1.remove()
            r2.remove()
            CallManager.stopIncomingListener()
        }
    }

    val myUid = Repo.uid
    val me = users.firstOrNull { it.uid == myUid }
    val others = users.filter { it.uid != myUid }
    val inChat = chatWith != null
    BackHandler(inChat) { chatWith = null }
    BackHandler(!inChat && CallManager.state == CallState.Idle) { onExit() }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize()) {
            val cw = chatWith?.let { c -> others.firstOrNull { it.uid == c.uid } ?: c }
            if (cw != null) {
                ChatScreen(cw) { chatWith = null }
            } else {
                AnimatedContent(
                    targetState = tab,
                    modifier = Modifier.fillMaxSize(),
                    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
                    label = "ptab"
                ) { t ->
                    when (t) {
                        0 -> HomeTab(me, others, chats) { chatWith = it }
                        1 -> ChatsTab(others, chats) { chatWith = it }
                        2 -> PeopleTab(others) { chatWith = it }
                        else -> ProfileTab(me, onExit)
                    }
                }
                FloatingNav(
                    listOf(
                        Icons.Filled.Home to "Home", Icons.Filled.Chat to "Chats",
                        Icons.Filled.Group to "People", Icons.Filled.Person to "Profile"
                    ),
                    tab, { tab = it }, Modifier.align(Alignment.BottomCenter)
                )
            }
        }
        if (CallManager.state != CallState.Idle) CallScreen()
    }
}

@Composable
fun ScreenTitle(text: String) {
    Text(
        text, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.padding(start = 20.dp, top = 24.dp, bottom = 12.dp)
    )
}

@Composable
fun EmptyCard(text: String) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .glass(RoundedCornerShape(22.dp), 0.06f).padding(24.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp) }
}

@Composable
fun ChatRow(user: UserProfile, last: String, time: Long, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
            .glass(RoundedCornerShape(20.dp), 0.07f).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(user.name, 52.dp, user.online)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(user.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(last, color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp, maxLines = 1)
        }
        Text(fmtTime(time), color = Color.White.copy(alpha = 0.45f), fontSize = 11.sp)
    }
}

@Composable
fun HomeTab(me: UserProfile?, others: List<UserProfile>, chats: List<ChatSummary>, onChat: (UserProfile) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hello,", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
                    Text(
                        me?.name ?: Repo.myName,
                        style = TextStyle(
                            brush = Brush.horizontalGradient(listOf(Violet, Cyan)),
                            fontSize = 28.sp, fontWeight = FontWeight.ExtraBold
                        )
                    )
                }
                Avatar(me?.name ?: Repo.myName, 52.dp, true)
            }
        }
        item {
            Text("Online now", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                modifier = Modifier.padding(start = 20.dp, bottom = 10.dp))
            val on = others.filter { it.online }
            if (on.isEmpty()) {
                EmptyCard("Abhi koi online nahi hai")
            } else {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(on) { u ->
                        Tilt3D(Modifier.width(96.dp).height(120.dp), RoundedCornerShape(22.dp), onClick = { onChat(u) }) {
                            Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.08f)))
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Avatar(u.name, 56.dp, true)
                                Spacer(Modifier.height(8.dp))
                                Text(u.name, color = Color.White, fontSize = 12.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Recent chats", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                modifier = Modifier.padding(start = 20.dp, bottom = 6.dp))
        }
        val recent = chats.take(4).mapNotNull { c -> others.firstOrNull { it.uid == c.otherUid }?.let { it to c } }
        if (recent.isEmpty()) {
            item { EmptyCard("Koi chat nahi. People tab se kisi ko message karo") }
        } else {
            items(recent) { (u, c) -> ChatRow(u, c.last, c.time) { onChat(u) } }
        }
    }
}

@Composable
fun ChatsTab(others: List<UserProfile>, chats: List<ChatSummary>, onChat: (UserProfile) -> Unit) {
    val rows = chats.mapNotNull { c -> others.firstOrNull { it.uid == c.otherUid }?.let { it to c } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item { ScreenTitle("Chats") }
        if (rows.isEmpty()) {
            item { EmptyCard("Abhi tak koi chat nahi") }
        } else {
            items(rows) { (u, c) -> ChatRow(u, c.last, c.time) { onChat(u) } }
        }
    }
}

@Composable
fun PeopleTab(others: List<UserProfile>, onChat: (UserProfile) -> Unit) {
    var q by remember { mutableStateOf("") }
    val gate = rememberMicGate()
    val list = others.filter { it.name.contains(q, true) || it.username.contains(q, true) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item { ScreenTitle("People") }
        item {
            GlassField(q, { q = it }, "Name ya username search karo", Icons.Filled.Search,
                modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(10.dp))
        }
        if (list.isEmpty()) {
            item { EmptyCard("Koi user nahi mila. Dost ko app install karke account banane bolo") }
        } else {
            items(list) { u ->
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                        .glass(RoundedCornerShape(20.dp), 0.07f).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u.name, 50.dp, u.online)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("@${u.username}", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                    }
                    IconButton(onClick = { onChat(u) }) { Icon(Icons.Filled.Chat, null, tint = Cyan) }
                    IconButton(onClick = { gate { CallManager.startCall(u.uid, u.name) } }) {
                        Icon(Icons.Filled.Call, null, tint = Color(0xFF00E676))
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileTab(me: UserProfile?, onExit: () -> Unit) {
    val name = me?.name ?: Repo.myName
    Column(Modifier.fillMaxSize().padding(start = 20.dp, end = 20.dp, bottom = 110.dp)) {
        ScreenTitle("Profile")
        Tilt3D(Modifier.fillMaxWidth().height(270.dp), RoundedCornerShape(30.dp)) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Violet, Color(0xFF311B92), Pink))))
            Column(
                Modifier.fillMaxSize().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Avatar(name, 92.dp, true)
                Spacer(Modifier.height(12.dp))
                Text(name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("@${me?.username ?: ""}", color = Color.White.copy(alpha = 0.8f))
                Text(me?.email ?: "", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.weight(1f))
        GradientButton("Lock & Exit") { onExit() }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier.fillMaxWidth().height(50.dp).glass(RoundedCornerShape(25.dp), 0.07f)
                .clickable { Repo.logout(); onExit() },
            contentAlignment = Alignment.Center
        ) { Text("Log out", color = Pink, fontWeight = FontWeight.Bold) }
    }
}

@Composable
fun Bubble(m: ChatMsg, mine: Boolean) {
    val vis = remember { MutableTransitionState(false).apply { targetState = true } }
    val shape = if (mine) RoundedCornerShape(20.dp, 20.dp, 4.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 4.dp)
    AnimatedVisibility(
        visibleState = vis,
        enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 2 } + scaleIn(tween(250), initialScale = 0.9f)
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = if (mine) Alignment.CenterEnd else Alignment.CenterStart) {
            Column(Modifier.widthIn(max = 290.dp), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                Text(
                    m.text, color = Color.White,
                    modifier = Modifier.clip(shape)
                        .background(
                            if (mine) Brush.linearGradient(listOf(Violet, Color(0xFF5E35B1)))
                            else SolidColor(Color.White.copy(alpha = 0.11f))
                        )
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                )
                Text(fmtTime(m.time), color = Color.White.copy(alpha = 0.4f), fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
    }
}

@Composable
fun ChatScreen(user: UserProfile, onBack: () -> Unit) {
    var msgs by remember { mutableStateOf(listOf<ChatMsg>()) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val gate = rememberMicGate()
    val myUid = Repo.uid

    DisposableEffect(user.uid) {
        val r = Repo.listenMessages(user.uid) { msgs = it }
        onDispose { r.remove() }
    }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1)
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp).glass(RoundedCornerShape(26.dp), 0.1f).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Avatar(user.name, 42.dp, user.online)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(user.name, color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    if (user.online) "online" else "offline",
                    color = if (user.online) Color(0xFF00E676) else Color.White.copy(alpha = 0.5f), fontSize = 12.sp
                )
            }
            IconButton(onClick = { gate { CallManager.startCall(user.uid, user.name) } }) {
                Icon(Icons.Filled.Call, null, tint = Color(0xFF00E676))
            }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 14.dp), state = listState,
            verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m, m.senderId == myUid) }
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp).glass(RoundedCornerShape(30.dp), 0.1f).padding(start = 8.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message likho...") }, maxLines = 4,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Cyan
                )
            )
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink)))
                    .clickable {
                        val text = input.trim()
                        if (text.isNotEmpty()) {
                            input = ""
                            scope.launch {
                                try { Repo.sendMessage(user.uid, text) } catch (e: Exception) { }
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White) }
        }
    }
}
