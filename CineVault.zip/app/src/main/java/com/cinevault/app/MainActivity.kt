package com.cinevault.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

enum class Mode { Streaming, Blackout, Auth, Private }

class MainActivity : ComponentActivity() {
    private var mode by mutableStateOf(Mode.Streaming)

    // Power button (screen off): call cut + wapas movie wale screen par, dobara password lagega
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            CallManager.endCall()
            mode = Mode.Streaming
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        ContextCompat.registerReceiver(
            this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        setContent {
            DisposableEffect(Unit) {
                val r = Catalog.listenUploads()
                onDispose { r?.remove() }
            }
            CineTheme {
                when (mode) {
                    Mode.Streaming -> StreamingApp(onDelete = { mode = Mode.Blackout })
                    Mode.Blackout -> BlackoutScreen(
                        onUnlock = { mode = if (Repo.uid != null) Mode.Private else Mode.Auth },
                        onBack = { mode = Mode.Streaming }
                    )
                    Mode.Auth -> AuthScreen(
                        onDone = { mode = Mode.Private },
                        onBack = { mode = Mode.Streaming }
                    )
                    Mode.Private -> PrivateApp(onExit = { mode = Mode.Streaming })
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenOff) } catch (e: Exception) { }
    }

    override fun onStart() {
        super.onStart()
        Repo.setOnline(true)
    }

    override fun onStop() {
        super.onStop()
        Repo.setOnline(false)
    }
}
