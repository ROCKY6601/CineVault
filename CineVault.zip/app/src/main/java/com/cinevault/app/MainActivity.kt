package com.cinevault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

enum class Mode { Streaming, Blackout, Auth, Private }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        setContent {
            DisposableEffect(Unit) {
                val r = Catalog.listenUploads()
                onDispose { r?.remove() }
            }
            CineTheme {
                var mode by remember { mutableStateOf(Mode.Streaming) }
                when (mode) {
                    Mode.Streaming -> StreamingApp(onDelete = { mode = Mode.Blackout })
                    Mode.Blackout -> BlackoutScreen(
                        onUnlock = { mode = if (Repo.uid != null) Mode.Private else Mode.Auth },
                        onBack = { mode = Mode.Streaming }
                    )
                    Mode.Auth -> AuthScreen(
                        onDone = { mode = Mode.Private },
                        onBack = { mode = Mode.Streaming }
                    )
                    Mode.Private -> PrivateApp(onExit = { mode = Mode.Streaming })
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Repo.setOnline(true)
    }

    override fun onStop() {
        super.onStop()
        Repo.setOnline(false)
    }
}
