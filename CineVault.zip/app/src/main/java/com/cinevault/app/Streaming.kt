@file:OptIn(
    androidx.compose.material3.ExperimentalMaterial3Api::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    coil.annotation.ExperimentalCoilApi::class
)

package com.cinevault.app

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import coil.imageLoader
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs

data class PlayReq(val movie: Movie, val url: String, val startMs: Long)

fun localMovie(f: File): Movie = Movie("local_" + f.name, f.nameWithoutExtension, "Download", "", "", "")

fun fmtMs(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun StreamingApp(onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Movie?>(null) }
    var playing by remember { mutableStateOf<PlayReq?>(null) }
    var busy by remember { mutableStateOf(false) }

    val startPlay: (Movie) -> Unit = { m ->
        scope.launch {
            busy = true
            val url = Catalog.resolveUrl(m)
            busy = false
            if (url == null) {
                Toast.makeText(ctx, "Yeh movie abhi play nahi ho pa rahi. Internet check karo ya dusri movie try karo", Toast.LENGTH_LONG).show()
            } else {
                playing = PlayReq(m, url, Prefs.progressOf(m.id))
            }
        }
    }

    BackHandler(playing != null) { playing = null }
    BackHandler(playing == null && open != null) { open = null }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground(Modifier.fillMaxSize()) {
            val o = open
            if (o != null) {
                DetailScreen(o, { open = null }, startPlay)
            } else {
                AnimatedContent(
                    targetState = tab,
                    modifier = Modifier.fillMaxSize(),
                    transitionSpec = { fadeIn(tween(350)) togetherWith fadeOut(tween(200)) },
                    label = "tab"
                ) { t ->
                    when (t) {
                        0 -> HomeScreen({ open = it }, { tab = 2 })
                        1 -> SearchScreen { open = it }
                        2 -> LibraryScreen({ open = it }) { f ->
                            playing = PlayReq(localMovie(f), Uri.fromFile(f).toString(), 0L)
                        }
                        else -> SettingsScreen(onDelete)
                    }
                }
                FloatingNav(
                    listOf(
                        Icons.Filled.Home to "Home", Icons.Filled.Search to "Search",
                        Icons.Filled.VideoLibrary to "Library", Icons.Filled.Settings to "Settings"
                    ),
                    tab, { tab = it }, Modifier.align(Alignment.BottomCenter)
                )
            }
        }
        val p = playing
        if (p != null) PlayerScreen(p) { playing = null }
        if (busy) {
            Box(
                Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)).pointerInput(Unit) { },
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator(color = Violet) }
        }
    }
}

@Composable
fun LogoHeader(onHeart: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) { LogoText(22) }
        Box(Modifier.size(40.dp).glass(CircleShape, 0.1f).clickable { onHeart() }, contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Favorite, null, tint = Pink, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun Hero(items: List<Movie>, onOpen: (Movie) -> Unit) {
    val pager = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(Prefs.heroAuto, items.size) {
        while (Prefs.heroAuto && items.isNotEmpty()) {
            delay(4500)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size)
        }
    }
    HorizontalPager(
        state = pager,
        contentPadding = PaddingValues(horizontal = 52.dp),
        pageSpacing = 8.dp,
        modifier = Modifier.fillMaxWidth().height(430.dp)
    ) { i ->
        val m = items[i]
        val offset = (pager.currentPage - i) + pager.currentPageOffsetFraction
        val dist = abs(offset).coerceIn(0f, 1f)
        Box(
            Modifier.fillMaxSize().padding(vertical = 8.dp)
                .graphicsLayer {
                    rotationY = offset * 30f
                    val s = lerp(0.86f, 1f, 1f - dist)
                    scaleX = s
                    scaleY = s
                    alpha = lerp(0.5f, 1f, 1f - dist)
                    cameraDistance = 16f * density
                }
                .clip(RoundedCornerShape(28.dp))
                .clickable { onOpen(m) }
        ) {
            PosterImage(m, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.9f))))
            Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                Text(m.category.uppercase(), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(m.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (m.year.isNotBlank()) Text(m.year, color = Color.White.copy(alpha = 0.75f))
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Violet, Pink)))
                        .clickable { onOpen(m) }.padding(horizontal = 22.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
                    Spacer(Modifier.width(6.dp))
                    Text("Watch", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CategoryChips(sel: String, onSel: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(Catalog.categories) { c ->
            val on = sel == c
            val bg by animateColorAsState(if (on) Violet else Color.White.copy(alpha = 0.08f), label = "chip")
            Text(
                c, color = Color.White,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(bg)
                    .clickable { onSel(c) }.padding(horizontal = 18.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp)
    )
}

@Composable
fun PosterCard(m: Movie, onOpen: (Movie) -> Unit, modifier: Modifier = Modifier.width(140.dp).height(210.dp)) {
    Tilt3D(modifier, onClick = { onOpen(m) }) {
        PosterImage(m, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.88f))))
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(m.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(if (m.year.isNotBlank()) m.year else m.category, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
        }
    }
}

@Composable
fun ContinueCard(h: HistoryItem, onOpen: (Movie) -> Unit) {
    val progress = if (h.durMs > 0) (h.posMs.toFloat() / h.durMs).coerceIn(0f, 1f) else 0f
    Tilt3D(Modifier.width(230.dp).height(130.dp), onClick = { onOpen(h.movie) }) {
        PosterImage(h.movie, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.3f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.85f))))
        Icon(
            Icons.Filled.PlayArrow, null, tint = Color.White,
            modifier = Modifier.align(Alignment.Center).size(42.dp).glass(CircleShape, 0.22f).padding(7.dp)
        )
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(h.movie.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.25f))) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Brush.horizontalGradient(listOf(Violet, Pink))))
            }
        }
    }
}

@Composable
fun MovieRow(title: String, list: List<Movie>, onOpen: (Movie) -> Unit) {
    SectionTitle(title)
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(list, key = { it.id }) { PosterCard(it, onOpen) }
    }
}

@Composable
fun ShimmerRow() {
    val t = rememberInfiniteTransition(label = "sh")
    val a by t.animateFloat(0.05f, 0.18f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "a")
    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        repeat(3) {
            Box(Modifier.width(140.dp).height(210.dp).clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = a)))
        }
    }
}

@Composable
fun HomeScreen(onOpen: (Movie) -> Unit, onLibrary: () -> Unit) {
    var cat by remember { mutableStateOf("All") }
    val uploads = Catalog.uploads
    val sel = if (cat in Catalog.categories) cat else "All"
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item { LogoHeader(onLibrary) }
        if (uploads.isEmpty()) {
            item {
                Spacer(Modifier.height(40.dp))
                EmptyCard("Abhi koi movie nahi hai.\nProfile > Movie add karo se apni movie jodo")
            }
        } else {
            item { Hero(uploads.take(6), onOpen) }
            item { CategoryChips(sel) { cat = it } }
            if (sel == "All") {
                if (Prefs.history.isNotEmpty()) {
                    item {
                        SectionTitle("Continue Watching")
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) { items(Prefs.history.toList(), key = { it.movie.id }) { ContinueCard(it, onOpen) } }
                    }
                }
                Catalog.categories.drop(1).forEach { c ->
                    item(key = "row_$c") { MovieRow(c, uploads.filter { it.category == c }, onOpen) }
                }
            } else {
                items(uploads.filter { it.category == sel }.chunked(3)) { row ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        row.forEach { PosterCard(it, onOpen, Modifier.weight(1f).aspectRatio(0.68f)) }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@Composable
fun MovieListRow(m: Movie, onOpen: (Movie) -> Unit, extra: String = "", trailing: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.07f).clickable { onOpen(m) }.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PosterImage(m, Modifier.size(width = 58.dp, height = 84.dp).clip(RoundedCornerShape(12.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                listOf(m.category, m.year).filter { it.isNotBlank() }.joinToString(" • "),
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp
            )
            if (extra.isNotEmpty()) Text(extra, color = Cyan, fontSize = 12.sp)
        }
        trailing()
    }
}

@Composable
fun SearchScreen(onOpen: (Movie) -> Unit) {
    var q by remember { mutableStateOf("") }
    val results = Catalog.uploads.filter { q.isBlank() || it.title.contains(q, true) || it.category.contains(q, true) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(20.dp))
        Text("Search", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(14.dp))
        GlassField(q, { q = it }, "Movie ka naam", Icons.Filled.Search)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            if (results.isEmpty()) item { EmptyCard("Kuch nahi mila") }
            items(results, key = { it.id }) { MovieListRow(it, onOpen) }
        }
    }
}

@Composable
fun DetailScreen(m: Movie, onBack: () -> Unit, onPlay: (Movie) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val fav = Prefs.favorites.any { it.id == m.id }
    val resume = Prefs.progressOf(m.id)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) {
            Icon(
                Icons.Filled.ChevronRight, null, tint = Color.White,
                modifier = Modifier.graphicsLayer { rotationZ = 180f }.glass(CircleShape, 0.12f)
                    .clickable { onBack() }.padding(8.dp).size(24.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Tilt3D(Modifier.width(240.dp).height(340.dp), RoundedCornerShape(26.dp)) {
            PosterImage(m, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(22.dp))
        Text(m.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(listOf(m.category, m.year).filter { it.isNotBlank() }.joinToString(" • "), color = Gold)
        Spacer(Modifier.height(12.dp))
        Text(m.desc, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
        Spacer(Modifier.height(22.dp))
        GradientButton(if (resume > 0) "Resume from ${fmtMs(resume)}" else "Play") { onPlay(m) }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                Modifier.weight(1f).height(50.dp).glass(RoundedCornerShape(25.dp), 0.1f).clickable {
                    scope.launch {
                        val url = Catalog.resolveUrl(m)
                        if (ytId(url ?: "") != null) {
                            Toast.makeText(ctx, "YouTube ki video download nahi ho sakti", Toast.LENGTH_SHORT).show()
                        } else if (url == null) {
                            Toast.makeText(ctx, "Download link nahi mila", Toast.LENGTH_SHORT).show()
                        } else {
                            enqueueDownload(ctx, m, url)
                            Toast.makeText(ctx, "Download shuru. Library > Downloads me dekho", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Download, null, tint = Cyan)
                Spacer(Modifier.width(8.dp))
                Text("Download", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
            Row(
                Modifier.weight(1f).height(50.dp).glass(RoundedCornerShape(25.dp), 0.1f).clickable { Prefs.toggleFav(m) },
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = Pink)
                Spacer(Modifier.width(8.dp))
                Text(if (fav) "In My List" else "My List", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
fun SettingCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp), 0.07f).padding(16.dp),
        content = content
    )
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp), 0.07f).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Violet, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun ActionRow(title: String, sub: String, icon: ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp), 0.07f)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = if (danger) Pink else Color.White, fontWeight = FontWeight.SemiBold)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
        }
        Icon(icon, null, tint = if (danger) Pink else Color.White.copy(alpha = 0.5f))
    }
}

@Composable
fun SettingsScreen(onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val minH = maxHeight
        Column(
            Modifier.verticalScroll(rememberScrollState()).heightIn(min = minH)
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 100.dp)
        ) {
            Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(14.dp))
            SettingCard {
                Text("Accent color", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("App ka theme color badlo", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    accents.forEachIndexed { i, c ->
                        Box(
                            Modifier.size(38.dp).clip(CircleShape).background(c)
                                .then(if (Prefs.accentIndex == i) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                                .clickable { Prefs.setAccent(i) }
                        )
                    }
                }
            }
            ToggleRow("Auto-scroll banner", "Home ka bada banner khud slide hoga", Prefs.heroAuto) { Prefs.updateHeroAuto(it) }
            ToggleRow("Downloads sirf Wi-Fi par", "Mobile data bachao", Prefs.wifiOnly) { Prefs.updateWifiOnly(it) }
            ActionRow("Watch history saaf karo", "Continue Watching list khaali hogi", Icons.Filled.History) {
                Prefs.clearHistory()
                Toast.makeText(ctx, "History saaf ho gayi", Toast.LENGTH_SHORT).show()
            }
            ActionRow("Image cache saaf karo", "Thumbnails dobara download honge", Icons.Filled.CleaningServices) {
                ctx.imageLoader.diskCache?.clear()
                ctx.imageLoader.memoryCache?.clear()
                Toast.makeText(ctx, "Cache saaf ho gaya", Toast.LENGTH_SHORT).show()
            }
            Spacer(Modifier.weight(1f))
            Spacer(Modifier.height(20.dp))
            ActionRow("Delete", "", Icons.Filled.Delete, danger = true, onClick = onDelete)
        }
    }
}
