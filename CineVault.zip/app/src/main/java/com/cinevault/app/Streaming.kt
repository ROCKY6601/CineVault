@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.cinevault.app

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.delay
import kotlin.math.abs

data class Title(
    val name: String, val category: String, val genre: String, val rating: String,
    val c1: Color, val c2: Color,
    val synopsis: String = "A gripping story with stunning visuals, unforgettable characters and a finale you will not see coming."
)

val categories = listOf("All", "Movies", "Anime", "Web Series", "Drama")

val sample = listOf(
    Title("Midnight Run", "Movies", "Action", "8.4", Color(0xFF7B1FA2), Color(0xFF1A237E)),
    Title("Neon City", "Movies", "Sci-Fi", "8.1", Color(0xFF00796B), Color(0xFF0D47A1)),
    Title("Last Horizon", "Movies", "Thriller", "7.9", Color(0xFFD84315), Color(0xFF3E2723)),
    Title("Silent Waves", "Movies", "Drama", "8.6", Color(0xFF283593), Color(0xFF000000)),
    Title("Sakura Blade", "Anime", "Fantasy", "9.0", Color(0xFFE91E63), Color(0xFF4A148C)),
    Title("Sky Pilots", "Anime", "Adventure", "8.7", Color(0xFF0288D1), Color(0xFF01579B)),
    Title("Ninja Academy", "Anime", "Action", "8.3", Color(0xFFF57C00), Color(0xFFBF360C)),
    Title("Spirit Garden", "Anime", "Slice of Life", "8.8", Color(0xFF388E3C), Color(0xFF1B5E20)),
    Title("The Syndicate", "Web Series", "Crime", "8.9", Color(0xFF455A64), Color(0xFF000000)),
    Title("Code Zero", "Web Series", "Tech", "8.2", Color(0xFF00ACC1), Color(0xFF004D40)),
    Title("Royal Blood", "Web Series", "Historical", "8.5", Color(0xFF8D6E63), Color(0xFF3E2723)),
    Title("Dark Signal", "Web Series", "Mystery", "8.0", Color(0xFF5E35B1), Color(0xFF1A1A1A)),
    Title("Ghar Ki Baatein", "Drama", "Family", "8.1", Color(0xFFEF6C00), Color(0xFF6D4C41)),
    Title("Dil Ke Paas", "Drama", "Romance", "7.8", Color(0xFFC2185B), Color(0xFF880E4F)),
    Title("Second Chance", "Drama", "Emotional", "8.4", Color(0xFF546E7A), Color(0xFF263238)),
    Title("City Lights", "Drama", "Slice of Life", "8.0", Color(0xFFFFA000), Color(0xFF4E342E))
)

@Composable
fun StreamingApp(onDelete: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Title?>(null) }
    BackHandler(open != null) { open = null }
    AuroraBackground(Modifier.fillMaxSize()) {
        val o = open
        if (o != null) {
            DetailScreen(o) { open = null }
        } else {
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.fillMaxSize(),
                transitionSpec = { fadeIn(tween(350)) togetherWith fadeOut(tween(200)) },
                label = "tab"
            ) { t ->
                when (t) {
                    0 -> HomeScreen { open = it }
                    1 -> SearchScreen { open = it }
                    else -> SettingsScreen(onDelete)
                }
            }
            FloatingNav(
                listOf(Icons.Filled.Home to "Home", Icons.Filled.Search to "Search", Icons.Filled.Settings to "Settings"),
                tab, { tab = it }, Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
fun PosterArt(t: Title, modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.linearGradient(listOf(t.c1, t.c2)))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color.White.copy(alpha = 0.10f), size.width * 0.6f, Offset(size.width * 0.9f, size.height * 0.15f))
            drawCircle(Color.Black.copy(alpha = 0.18f), size.width * 0.5f, Offset(size.width * 0.1f, size.height * 0.95f))
            drawCircle(Color.White.copy(alpha = 0.06f), size.width * 0.25f, Offset(size.width * 0.3f, size.height * 0.3f))
        }
    }
}

@Composable
fun LogoHeader() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            "CINEVAULT",
            style = TextStyle(
                brush = Brush.horizontalGradient(listOf(Violet, Cyan)),
                fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
            ),
            modifier = Modifier.weight(1f)
        )
        Box(Modifier.size(38.dp).glass(CircleShape, 0.1f), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun Hero(onOpen: (Title) -> Unit) {
    val items = remember { sample.filter { it.rating.toDouble() >= 8.5 }.take(6) }
    val pager = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(pager) {
        while (true) {
            delay(4500)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size)
        }
    }
    HorizontalPager(
        state = pager,
        contentPadding = PaddingValues(horizontal = 52.dp),
        pageSpacing = 8.dp,
        modifier = Modifier.fillMaxWidth().height(430.dp)
    ) { i ->
        val t = items[i]
        val offset = (pager.currentPage - i) + pager.currentPageOffsetFraction
        val dist = abs(offset).coerceIn(0f, 1f)
        Box(
            Modifier.fillMaxSize().padding(vertical = 8.dp)
                .graphicsLayer {
                    rotationY = offset * 30f
                    val s = lerp(0.86f, 1f, 1f - dist)
                    scaleX = s
                    scaleY = s
                    alpha = lerp(0.5f, 1f, 1f - dist)
                    cameraDistance = 16f * density
                }
                .clip(RoundedCornerShape(28.dp))
                .clickable { onOpen(t) }
        ) {
            PosterArt(t, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)), startY = 250f)))
            Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                Text(t.category.uppercase(), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(t.name, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("★ ${t.rating}  •  ${t.genre}", color = Color.White.copy(alpha = 0.75f))
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Violet, Pink)))
                        .clickable { onOpen(t) }.padding(horizontal = 22.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
                    Spacer(Modifier.width(6.dp))
                    Text("Play", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CategoryChips(sel: String, onSel: (String) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(categories) { c ->
            val on = sel == c
            val bg by animateColorAsState(if (on) Violet else Color.White.copy(alpha = 0.08f), label = "chip")
            Text(
                c, color = Color.White,
                fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(bg)
                    .clickable { onSel(c) }.padding(horizontal = 18.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp)
    )
}

@Composable
fun PosterCard(t: Title, onOpen: (Title) -> Unit) {
    Tilt3D(Modifier.width(140.dp).height(210.dp), onClick = { onOpen(t) }) {
        PosterArt(t, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f)), startY = 200f)))
        Text(
            "★ ${t.rating}", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).glass(RoundedCornerShape(10.dp), 0.18f)
                .padding(horizontal = 7.dp, vertical = 3.dp)
        )
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(t.genre, color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
        }
    }
}

@Composable
fun ContinueCard(t: Title, progress: Float, onOpen: (Title) -> Unit) {
    Tilt3D(Modifier.width(230.dp).height(130.dp), onClick = { onOpen(t) }) {
        PosterArt(t, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)))))
        Icon(
            Icons.Filled.PlayArrow, null, tint = Color.White,
            modifier = Modifier.align(Alignment.Center).size(42.dp).glass(CircleShape, 0.22f).padding(7.dp)
        )
        Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            Text(t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.25f))) {
                Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Brush.horizontalGradient(listOf(Violet, Pink))))
            }
        }
    }
}

@Composable
fun Section(category: String, onOpen: (Title) -> Unit) {
    SectionTitle(category)
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(sample.filter { it.category == category }) { PosterCard(it, onOpen) }
    }
}

@Composable
fun HomeScreen(onOpen: (Title) -> Unit) {
    var cat by remember { mutableStateOf("All") }
    val prog = remember { listOf(0.7f, 0.35f, 0.9f, 0.5f) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 120.dp)) {
        item { LogoHeader() }
        item { Hero(onOpen) }
        item { CategoryChips(cat) { cat = it } }
        if (cat == "All") {
            item {
                SectionTitle("Continue Watching")
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    itemsIndexed(sample.take(4)) { i, t -> ContinueCard(t, prog[i], onOpen) }
                }
            }
        }
        val rows = if (cat == "All") categories.drop(1) else listOf(cat)
        items(rows) { r -> Section(r, onOpen) }
    }
}

@Composable
fun SearchScreen(onOpen: (Title) -> Unit) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(20.dp))
        Text("Search", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(14.dp))
        GlassField(q, { q = it }, "Movies, anime, series...", Icons.Filled.Search)
        Spacer(Modifier.height(14.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
            items(sample.filter { it.name.contains(q, true) || it.genre.contains(q, true) || it.category.contains(q, true) }) { t ->
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp), 0.07f).clickable { onOpen(t) }.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PosterArt(t, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${t.category} • ${t.genre}", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                    }
                    Text("★ ${t.rating}", color = Gold, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(t: Title, onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth()) {
            Icon(
                Icons.Filled.ChevronRight, null, tint = Color.White,
                modifier = Modifier.graphicsLayer { rotationZ = 180f }.glass(CircleShape, 0.12f)
                    .clickable { onBack() }.padding(8.dp).size(24.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Tilt3D(Modifier.width(240.dp).height(340.dp), RoundedCornerShape(26.dp)) {
            PosterArt(t, Modifier.fillMaxSize())
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)), startY = 400f)))
        }
        Spacer(Modifier.height(22.dp))
        Text(t.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text("${t.category} • ${t.genre} • ★ ${t.rating}", color = Gold)
        Spacer(Modifier.height(12.dp))
        Text(t.synopsis, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
        Spacer(Modifier.weight(1f))
        GradientButton("Play") {
            Toast.makeText(ctx, "Video source abhi connect nahi hai", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun SettingRow(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, danger: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).glass(RoundedCornerShape(16.dp), 0.07f)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = if (danger) Pink else Color.White, modifier = Modifier.weight(1f))
        Icon(icon, null, tint = if (danger) Pink else Color.White.copy(alpha = 0.5f))
    }
}

@Composable
fun SettingsScreen(onDelete: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 100.dp)) {
        Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        Tilt3D(Modifier.fillMaxWidth().height(110.dp), RoundedCornerShape(24.dp)) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Violet, Color(0xFF311B92), Pink))))
            Row(Modifier.fillMaxSize().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar("C", 60.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text("CineVault Premium", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Active • Ultra HD", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        listOf("Account", "Notifications", "Playback quality", "Downloads", "About").forEach {
            SettingRow(it, Icons.Filled.ChevronRight) { }
        }
        Spacer(Modifier.weight(1f))
        SettingRow("Delete", Icons.Filled.Delete, danger = true, onClick = onDelete)
    }
}
