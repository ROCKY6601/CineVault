# CineVault
1. Is folder ko GitHub repo me upload karo (branch: main).
2. Actions tab -> "Build APK" chalne do.
3. Artifacts se CineVault-debug-apk download karo.
Default password: 1234 (Private.kt me UNLOCK_PASSWORD).
