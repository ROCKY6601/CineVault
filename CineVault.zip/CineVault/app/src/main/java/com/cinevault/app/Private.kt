package com.cinevault.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// TODO: change this password (later: store it securely and let the user set it)
const val UNLOCK_PASSWORD = "1234"

@Composable
fun BlackoutScreen(onUnlock: () -> Unit, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    BackHandler(onBack = onBack)
    Box(
        Modifier.fillMaxSize().background(Color.Black).pointerInput(Unit) {
            detectTapGestures {
                focus.requestFocus()
                keyboard?.show()
            }
        }
    ) {
        BasicTextField(
            value = text,
            onValueChange = {
                text = it
                if (it == UNLOCK_PASSWORD) onUnlock()
            },
            modifier = Modifier.size(1.dp).focusRequester(focus),
            textStyle = TextStyle(color = Color.Black),
            cursorBrush = SolidColor(Color.Black),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { if (text == UNLOCK_PASSWORD) onUnlock() else text = "" })
        )
    }
}

data class Contact(val name: String, val last: String, val online: Boolean)
data class Msg(val text: String, val mine: Boolean)

val contacts = listOf(
    Contact("Aarav", "Kal milte hain", true),
    Contact("Priya", "Ok done", true),
    Contact("Rohan", "Photo bhej do", false),
    Contact("Sneha", "Good night", false),
    Contact("Kabir", "Call me", true)
)

@Composable
fun PrivateApp(onExit: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var chat by remember { mutableStateOf<Contact?>(null) }
    var calling by remember { mutableStateOf<Contact?>(null) }
    BackHandler(chat != null || calling != null) { if (calling != null) calling = null else chat = null }

    when {
        calling != null -> CallScreen(calling!!.name) { calling = null }
        chat != null -> ChatScreen(chat!!, onBack = { chat = null }, onCall = { calling = chat })
        else -> Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Surf) {
                    NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Chat, null) }, label = { Text("Chats") })
                    NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Call, null) }, label = { Text("Calls") })
                    NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Filled.Person, null) }, label = { Text("Profile") })
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
                when (tab) {
                    0 -> PHome(onOpen = { chat = it })
                    1 -> ChatList(onOpen = { chat = it })
                    2 -> CallList(onCall = { calling = it })
                    else -> ProfileTab(onExit)
                }
            }
        }
    }
}

@Composable
fun Avatar(name: String, size: Dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Accent.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) { Text(name.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value / 2.4f).sp) }
}

@Composable
fun PHome(onOpen: (Contact) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Welcome back", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Online now", color = Color.Gray)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            items(contacts.filter { it.online }) { c ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onOpen(c) }) {
                    Avatar(c.name, 60.dp)
                    Text(c.name, color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ChatList(onOpen: (Contact) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Chats", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        items(contacts) { c ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surf)
                    .clickable { onOpen(c) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(c.name, 46.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(c.last, color = Color.Gray, fontSize = 13.sp)
                }
                if (c.online) Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFF4CAF50)))
            }
        }
    }
}

@Composable
fun CallList(onCall: (Contact) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Calls", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold) }
        items(contacts) { c ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surf).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(c.name, 46.dp)
                Spacer(Modifier.width(12.dp))
                Text(c.name, color = Color.White, modifier = Modifier.weight(1f))
                IconButton(onClick = { onCall(c) }) { Icon(Icons.Filled.Call, null, tint = Accent) }
            }
        }
    }
}

@Composable
fun ProfileTab(onExit: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Avatar("Me", 110.dp)
        Spacer(Modifier.height(12.dp))
        Text("My Profile", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Available", color = Color.Gray)
        Spacer(Modifier.weight(1f))
        Button(
            onClick = onExit, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Accent)
        ) { Text("Lock & Exit") }
    }
}

@Composable
fun ChatScreen(c: Contact, onBack: () -> Unit, onCall: () -> Unit) {
    val msgs: SnapshotStateList<Msg> = remember {
        mutableStateListOf(Msg("Hi!", false), Msg("Hello, kaise ho?", true))
    }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.size - 1) }
    Column(Modifier.fillMaxSize().background(Bg).imePadding()) {
        Row(Modifier.fillMaxWidth().background(Surf).padding(8.dp).statusBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Avatar(c.name, 38.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(c.name, color = Color.White, fontWeight = FontWeight.Bold)
                Text(if (c.online) "online" else "offline", color = Color.Gray, fontSize = 12.sp)
            }
            IconButton(onClick = onCall) { Icon(Icons.Filled.Call, null, tint = Accent) }
        }
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 12.dp), state = listState,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(msgs) { m ->
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(
                        m.text, color = Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (m.mine) Accent else Surf).padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(8.dp).navigationBarsPadding(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message") }, maxLines = 3
            )
            IconButton(onClick = {
                if (input.isNotBlank()) { msgs.add(Msg(input.trim(), true)); input = "" }
            }) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = Accent) }
        }
    }
}

@Composable
fun CallScreen(name: String, onEnd: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pulse")
    val s by inf.animateFloat(1f, 1.35f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    Column(
        Modifier.fillMaxSize().background(Bg),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(contentAlignment = Alignment.Center) {
            Box(Modifier.size(150.dp).scale(s).clip(CircleShape).background(Accent.copy(alpha = 0.25f)))
            Avatar(name, 110.dp)
        }
        Spacer(Modifier.height(24.dp))
        Text(name, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Calling...", color = Color.Gray)
        Spacer(Modifier.height(48.dp))
        FilledIconButton(
            onClick = onEnd, modifier = Modifier.size(68.dp),
            colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFD32F2F))
        ) { Icon(Icons.Filled.CallEnd, null, tint = Color.White) }
    }
}
