package com.cinevault.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

data class Title(
    val name: String, val category: String, val genre: String,
    val rating: String, val c1: Color, val c2: Color
)

val categories = listOf("All", "Movies", "Anime", "Web Series", "Drama")

val sample = listOf(
    Title("Midnight Run", "Movies", "Action", "8.4", Color(0xFF7B1FA2), Color(0xFF1A237E)),
    Title("Neon City", "Movies", "Sci-Fi", "8.1", Color(0xFF00796B), Color(0xFF0D47A1)),
    Title("Last Horizon", "Movies", "Thriller", "7.9", Color(0xFFD84315), Color(0xFF3E2723)),
    Title("Silent Waves", "Movies", "Drama", "8.6", Color(0xFF283593), Color(0xFF000000)),
    Title("Sakura Blade", "Anime", "Fantasy", "9.0", Color(0xFFE91E63), Color(0xFF4A148C)),
    Title("Sky Pilots", "Anime", "Adventure", "8.7", Color(0xFF0288D1), Color(0xFF01579B)),
    Title("Ninja Academy", "Anime", "Action", "8.3", Color(0xFFF57C00), Color(0xFFBF360C)),
    Title("Spirit Garden", "Anime", "Slice of Life", "8.8", Color(0xFF388E3C), Color(0xFF1B5E20)),
    Title("The Syndicate", "Web Series", "Crime", "8.9", Color(0xFF455A64), Color(0xFF000000)),
    Title("Code Zero", "Web Series", "Tech", "8.2", Color(0xFF00ACC1), Color(0xFF004D40)),
    Title("Royal Blood", "Web Series", "Historical", "8.5", Color(0xFF8D6E63), Color(0xFF3E2723)),
    Title("Dark Signal", "Web Series", "Mystery", "8.0", Color(0xFF5E35B1), Color(0xFF1A1A1A)),
    Title("Ghar Ki Baatein", "Drama", "Family", "8.1", Color(0xFFEF6C00), Color(0xFF6D4C41)),
    Title("Dil Ke Paas", "Drama", "Romance", "7.8", Color(0xFFC2185B), Color(0xFF880E4F)),
    Title("Second Chance", "Drama", "Emotional", "8.4", Color(0xFF546E7A), Color(0xFF263238)),
    Title("City Lights", "Drama", "Slice of Life", "8.0", Color(0xFFFFA000), Color(0xFF4E342E))
)

@Composable
fun StreamingApp(onDelete: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surf) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Filled.Search, null) }, label = { Text("Search") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Filled.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
                label = "tab"
            ) { t ->
                when (t) {
                    0 -> HomeScreen()
                    1 -> SearchScreen()
                    else -> SettingsScreen(onDelete)
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    var cat by remember { mutableStateOf("All") }
    LazyColumn(Modifier.fillMaxSize().background(Bg), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Hero() }
        item {
            LazyRow(
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { c ->
                    FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) })
                }
            }
        }
        val rows = if (cat == "All") categories.drop(1) else listOf(cat)
        items(rows) { r -> Section(r) }
    }
}

@Composable
fun Hero() {
    val items = remember { sample.filter { it.rating.toDouble() >= 8.5 }.take(5) }
    val pager = rememberPagerState(pageCount = { items.size })
    LaunchedEffect(pager) {
        while (true) {
            delay(4000)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size)
        }
    }
    HorizontalPager(pager, Modifier.fillMaxWidth().height(400.dp)) { i ->
        val t = items[i]
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(t.c1, t.c2)))) {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Bg), startY = 300f))
            )
            Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                Text(t.category.uppercase(), color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(t.name, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Text("★ ${t.rating}  •  ${t.genre}", color = Color.LightGray)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Accent)) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
            }
        }
    }
}

@Composable
fun Section(category: String) {
    Text(
        category, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp)
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(sample.filter { it.category == category }) { PosterCard(it) }
    }
}

@Composable
fun PosterCard(t: Title) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(), label = "press")
    Box(
        Modifier.width(130.dp).height(190.dp).scale(scale)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(t.c1, t.c2)))
            .clickable(interactionSource = src, indication = null) { },
        contentAlignment = Alignment.BottomStart
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(t.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("★ ${t.rating}", color = Color.LightGray, fontSize = 12.sp)
        }
    }
}

@Composable
fun SearchScreen() {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        OutlinedTextField(
            value = q, onValueChange = { q = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search movies, anime, series...") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sample.filter { it.name.contains(q, true) || it.genre.contains(q, true) }) { t ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surf).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Brush.linearGradient(listOf(t.c1, t.c2))))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(t.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${t.category} • ${t.genre} • ★ ${t.rating}", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onDelete: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Text("Settings", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        listOf("Account", "Notifications", "Playback quality", "Downloads", "Language", "About").forEach {
            SettingRow(it, Icons.Filled.ChevronRight) { }
        }
        Spacer(Modifier.weight(1f))
        SettingRow("Delete", Icons.Filled.Delete, onClick = onDelete)
    }
}

@Composable
fun SettingRow(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp))
            .background(Surf).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Color.White, modifier = Modifier.weight(1f))
        Icon(icon, null, tint = Color.Gray)
    }
}
