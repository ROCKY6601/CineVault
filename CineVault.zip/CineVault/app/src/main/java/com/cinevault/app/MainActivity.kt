package com.cinevault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

enum class Mode { Streaming, Blackout, Private }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CineTheme {
                var mode by remember { mutableStateOf(Mode.Streaming) }
                when (mode) {
                    Mode.Streaming -> StreamingApp(onDelete = { mode = Mode.Blackout })
                    Mode.Blackout -> BlackoutScreen(
                        onUnlock = { mode = Mode.Private },
                        onBack = { mode = Mode.Streaming }
                    )
                    Mode.Private -> PrivateApp(onExit = { mode = Mode.Streaming })
                }
            }
        }
    }
}
