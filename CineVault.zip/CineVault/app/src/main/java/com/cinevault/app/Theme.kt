package com.cinevault.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B0B10)
val Surf = Color(0xFF15151D)
val Accent = Color(0xFFFF3D5A)

@Composable
fun CineTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Surf,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}
