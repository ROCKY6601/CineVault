# CineVault
1. google-services.json ko repo ke root me upload karo.
2. CineVault.zip upload karo (ya files extract karke).
3. Actions -> Build APK -> Artifacts se APK.
Firebase: Authentication -> Email/Password ON, Firestore Database create, firestore.rules paste.
Default unlock password: 1234 (Blackout.kt).
