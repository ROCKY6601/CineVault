# NUXUS MOVIES
1. google-services.json repo ke root me rakho.
2. CineVault.zip upload karo -> Actions -> Build APK -> Artifacts se APK.
Default unlock code: 1234 (Profile tab me badal sakte ho).
Firebase: Authentication Email/Password ON, Firestore create, firestore.rules paste.
