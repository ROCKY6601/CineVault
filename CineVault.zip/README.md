# CineVault
Zip ko extract karke files repo me daalo, YA CineVault.zip ko repo me upload rehne do (workflow khud unzip kar leta hai).
Actions -> Build APK -> Artifacts se APK download karo.
Default password: 1234 (Private.kt me UNLOCK_PASSWORD).
